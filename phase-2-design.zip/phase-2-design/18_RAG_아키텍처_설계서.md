# 18 RAG 아키텍처 설계서

## 1. 문서 정보

-   Development Phase: P1 Prototype
-   Scope: Level 2 Functional Prototype
-   Maturity: L2 Prototype
-   ASM-001: AI/RAG 미적용
-   ASM-002: 업무 역할 기반 RBAC
-   기술 기준(원천 요구사항): NestJS 모듈 구조, PostgreSQL, JWT/RBAC,
    TLS 1.3, AES-256, Kubernetes 확장 구조
-   주의: Production 운영 수준 HA/DR/실연동은 P2 고도화 대상

## 2. Applicability

**N/A / L0**

## 3. 비적용 사유

P1 요구범위에 문서 검색·생성형 질의응답 또는 RAG가 없다.

## 4. 추적성

ASM-001 → DOC-18=N/A.

## 5. 완료 기준

Vector DB, Embedding, Retriever, LLM 구성요소를 P1 아키텍처에 포함하지
않는다.
