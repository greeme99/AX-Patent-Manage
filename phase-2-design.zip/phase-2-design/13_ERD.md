# 13 ERD

## 1. 문서 정보

-   Development Phase: P1 Prototype
-   Scope: Level 2 Functional Prototype
-   Maturity: L2 Prototype
-   ASM-001: AI/RAG 미적용
-   ASM-002: 업무 역할 기반 RBAC
-   기술 기준(원천 요구사항): NestJS 모듈 구조, PostgreSQL, JWT/RBAC,
    TLS 1.3, AES-256, Kubernetes 확장 구조
-   주의: Production 운영 수준 HA/DR/실연동은 P2 고도화 대상

## 2. 목적

8대 도메인, Workflow, 품질, RBAC, Audit의 P1 논리 데이터 모델을
정의한다.

## 3. 설계 원칙

-   공통 Master 헤더와 도메인별 상세 테이블을 분리한다.
-   승인된 현재 버전과 변경 요청을 분리한다.
-   모든 변경 요청은 Validation/Audit와 연결한다.
-   외부 시스템 식별자는 별도 Mapping으로 관리한다.

## 4. ERD

``` mermaid
erDiagram
  USER ||--o{ USER_ROLE : has
  ROLE ||--o{ USER_ROLE : assigned
  MASTER_RECORD ||--o{ MASTER_VERSION : versions
  MASTER_RECORD ||--o{ CHANGE_REQUEST : requested_for
  CHANGE_REQUEST ||--o{ CHANGE_ITEM : contains
  CHANGE_REQUEST ||--o{ WORKFLOW_ACTION : actions
  CHANGE_REQUEST ||--o{ VALIDATION_RESULT : validated
  VALIDATION_RULE ||--o{ VALIDATION_RESULT : produces
  MASTER_RECORD ||--o{ AUDIT_LOG : audited
  MASTER_RECORD ||--o{ EXTERNAL_MAPPING : maps

  MASTER_RECORD ||--o| MATERIAL_DETAIL : material
  MASTER_RECORD ||--o| BOM_DETAIL : bom
  MASTER_RECORD ||--o| ROUTING_DETAIL : routing
  MASTER_RECORD ||--o| EQUIPMENT_DETAIL : equipment
  MASTER_RECORD ||--o| SUPPLIER_DETAIL : supplier
  MASTER_RECORD ||--o| PRODUCT_CUSTOMER_DETAIL : product_customer
  MASTER_RECORD ||--o| MRO_DETAIL : mro
  MASTER_RECORD ||--o| ENGINEERING_DETAIL : engineering

  QUALITY_SNAPSHOT ||--o{ QUALITY_METRIC : contains
```

## 5. 주요 관계

-   MASTER_RECORD 1:N MASTER_VERSION
-   MASTER_RECORD 1:N CHANGE_REQUEST
-   CHANGE_REQUEST 1:N CHANGE_ITEM/WORKFLOW_ACTION/VALIDATION_RESULT
-   VALIDATION_RULE 1:N VALIDATION_RESULT
-   USER N:M ROLE
-   MASTER_RECORD 1:N EXTERNAL_MAPPING

## 6. 제약

8대 도메인의 전체 물리 속성은 원천 요구사항의 핵심 속성을 우선 반영하고
P2에서 ERP/PLM 실제 스키마에 맞춰 확장한다.

## 7. 추적성

FR-MDM-\* → MASTER_RECORD/MASTER_VERSION FR-WF-\* →
CHANGE_REQUEST/WORKFLOW_ACTION FR-DQ-\* → VALIDATION_RULE/RESULT,
QUALITY\_* FR-IAM-* → USER/ROLE/USER_ROLE FR-AUD-001 → AUDIT_LOG

## 8. 완료 기준

API DTO가 모든 핵심 엔터티와 매핑 가능해야 한다.
