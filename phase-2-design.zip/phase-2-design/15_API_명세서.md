# 15 API 명세서

## 1. 문서 정보

-   Development Phase: P1 Prototype
-   Scope: Level 2 Functional Prototype
-   Maturity: L2 Prototype
-   ASM-001: AI/RAG 미적용
-   ASM-002: 업무 역할 기반 RBAC
-   기술 기준(원천 요구사항): NestJS 모듈 구조, PostgreSQL, JWT/RBAC,
    TLS 1.3, AES-256, Kubernetes 확장 구조
-   주의: Production 운영 수준 HA/DR/실연동은 P2 고도화 대상

## 2. 공통

Base Prefix: `/api/v1` 인증: `Authorization: Bearer <JWT>` 응답은
`data`, `meta`, `error`, `traceId` 계약을 사용한다.

## 3. API 목록

  --------------------------------------------------------------------------------------------------
  API ID         Method/Path                     기능           권한               테이블
  -------------- ------------------------------- -------------- ------------------ -----------------
  API-MDM-001    GET /masters                    검색           Viewer+            TBL-MDM-001

  API-MDM-002    GET /masters/:id                상세           Viewer+            TBL-MDM-001/002

  API-MDM-003    POST /change-requests           신규/변경      Requester+         TBL-WF-001/002
                                                 Draft                             

  API-MDM-004    PATCH /change-requests/:id      Draft 수정     Requester(본인)+   TBL-WF-001/002

  API-DQ-001     POST                            Rule           Requester+         TBL-DQ-001/002
                 /change-requests/:id/validate   Validation                        

  API-DQ-002     GET /quality/metrics            품질 KPI       Viewer+            TBL-DQ-003/004

  API-WF-001     POST                            제출           Requester          TBL-WF-001/003
                 /change-requests/:id/submit                                       

  API-WF-002     POST                            Steward 검토   Steward            TBL-WF-001/003
                 /change-requests/:id/review                                       

  API-WF-003     POST                            승인           Owner              TBL-WF-001/003
                 /change-requests/:id/approve                                      

  API-WF-004     POST                            반려           Owner              TBL-WF-001/003
                 /change-requests/:id/reject                                       

  API-AUD-001    GET /audit-logs                 감사조회       권한 필요          TBL-AUD-001

  API-ADM-001    GET/POST/PATCH                  Rule 관리      Admin              TBL-DQ-001
                 /validation-rules                                                 

  API-IAM-001    GET/POST/PATCH /users           사용자 관리    Admin              TBL-IAM-001

  API-IAM-002    PUT /users/:id/roles            Role 부여      Admin              TBL-IAM-003
  --------------------------------------------------------------------------------------------------

## 4. 상태 전이

DRAFT→REQUESTED→IN_REVIEW→APPROVED→APPLIED, 또는 IN_REVIEW→REJECTED.
REJECTED는 수정 후 재요청 가능.

## 5. 오류 코드

`AUTH_REQUIRED`, `FORBIDDEN`, `NOT_FOUND`, `INVALID_STATE`,
`VALIDATION_FAILED`, `CONFLICT`, `INTERNAL_ERROR`.

## 6. 예시

``` json
{
  "data": {
    "requestId": "CR-2026-000001",
    "status": "REQUESTED"
  },
  "meta": { "traceId": "..." },
  "error": null
}
```

## 7. 완료 기준

SCR 입력/출력, API DTO, TBL이 양방향 추적 가능해야 한다.
