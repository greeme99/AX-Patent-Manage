# Phase 2 Design --- P1 Level 2

## 문서

11 UI 디자인 가이드 12 디자인 시스템 13 ERD 14 테이블 정의서 15 API
명세서 16 시스템 아키텍처 17 AI 모델 --- N/A 18 RAG 아키텍처 --- N/A 19
프롬프트 가이드 --- N/A 20 보안 설계

## 핵심 결정

-   AI/RAG 미적용
-   업무 역할 기반 RBAC
-   P1 아키텍처: Modular Monolith + Worker
-   원천 기술 요구: NestJS, PostgreSQL, JWT/RBAC, TLS 1.3, AES-256,
    Kubernetes 확장 방향
-   외부 시스템: P1 Mock/Interface

## Phase 2 Quality Gate

화면→API→데이터→아키텍처 연결을 검증한다.
