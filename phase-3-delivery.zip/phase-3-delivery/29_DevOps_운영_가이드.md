# 29 DevOps 운영 가이드

## 1. 문서 정보

-   Development Phase: P1 Prototype
-   Scope: Level 2 Functional Prototype
-   Maturity: L2 Prototype
-   ASM-001: AI/RAG 미적용, Rule-based Validation
-   ASM-002: RBAC = Viewer / Requester / Data Steward / Data Owner /
    Admin
-   Phase 2 기준: Web Client + NestJS Modular Monolith + Background
    Worker + PostgreSQL
-   API Prefix: `/api/v1`
-   Workflow: DRAFT → REQUESTED → IN_REVIEW → APPROVED/REJECTED →
    APPLIED
-   주의: 실제 구현·배포·운영 완료 사실은 확인되지 않았으며 본 문서는 P1
    실행 설계 기준이다.

## 2. 목적

코드 변경부터 테스트·배포·롤백까지 반복 가능한 P1 파이프라인을 정의한다.

## 3. CI/CD

원천 요구사항은 GitHub Actions 기반 자동 테스트/배포를 제시한다.

``` text
PR
 → Lint
 → Type Check
 → Unit Test
 → Integration Test
 → Security Check
 → Build
 → Artifact/Image
 → test 배포
 → E2E/Smoke
 → prototype 승인 배포
```

## 4. Gate

-   자동 테스트 커버리지 80% 목표
-   Critical/High 결함 0
-   Migration 검증
-   Secret scan
-   승인 없는 prototype 배포 금지

## 5. 변경관리

-   기능 변경: FR/FS/API/TBL/PG/TC 영향 확인
-   DB 변경: Migration + rollback 계획
-   Rule 변경: Rule Version과 Audit 기록
-   Role 변경: Security 검토와 Audit 기록

## 6. Rollback

배포 버전, DB Migration 버전, Rule Version을 함께 식별한다. 장애 시 앱
버전 롤백 후 DB/Rule 호환성 검증을 수행한다.

## 7. 기술부채

원천 요구사항의 주간 코드 리뷰, 80% 테스트 커버리지, OpenAPI/Markdown
문서화 기준을 P1 기술부채 관리 기준으로 사용한다.

## 8. 완료 기준

동일 commit에서 재현 가능한 Build/Test/Deploy 결과가 생성되어야 한다.
