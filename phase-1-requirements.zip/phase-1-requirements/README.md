# P1 Level 2 Functional Prototype --- Phase 1 Requirements

이 패키지는 8대 기준정보 관리 포털 웹앱의 P1 요구사항 Baseline v0.3이다.

## 포함 문서

00 문서목록/추적성, 01\~10 Phase 1 개발문서.

## 적용 결정

-   ASM-001: AI 제외
-   ASM-002: 업무 역할 기반 RBAC
-   17\~19 AI/RAG/Prompt 문서는 Catalog에서 유지하되 P1 N/A 예정

## 다음 설계

11\~20 중 P1 적용 문서를 작성하면서 ERD, Table, API, Architecture,
Security를 구체화한다.
